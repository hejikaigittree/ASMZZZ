﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DLAF_SingleTrack
{
    public partial class UcFeedTracker : UserControl
    {
        public UcFeedTracker()
        {
            InitializeComponent();
        }

        private void UcFeedTracker_Load(object sender, EventArgs e)
        {

        }

        //松开夹手
        private void btOpenClamp_Click(object sender, EventArgs e)
        {

        }

        //夹手闭合

        private void btCloseClamp_Click(object sender, EventArgs e)
        {

        }

        //以指定的行程单次送料
        private void btFeed_Click(object sender, EventArgs e)
        {

        }
    }
}
