﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JFInterfaceDef;
using JFToolKits;
using JFHub;
using JFUI;

namespace DLAF_SingleTrack
{
    [JFDisplayName("单轨AOI下料轨道工站")]
    [JFVersion("1.0.0.0")]
    public class DLAF_EjectTracker:JFStationBase
    {
        /// <summary>
        /// 工站工作状态
        /// </summary>
        enum STStatus //single tracker's status
        {
            已停止,
            等待检测Z轴避位, //归零时等待Z轴抬起后，再进行下一步动作
            复位,
            开始运行,
            移动到待机位置,
            等待出料信号, //等待料仓向轨道送料完成信号
            出料, //轨道（自身）向检测位置送料
            //等待检测完成,
            //等待出料信号,//等待下料仓准备好
            //出料,

        }

        public DLAF_EjectTracker()
        {
            DeclearDevChn(NamedChnType.Axis, DevAN_AxisEject);
            DeclearDevChn(NamedChnType.Di, DevAN_DIEjectCldClose);
            DeclearDevChn(NamedChnType.Do, DevAN_DOEjectCldCtrl);
            DeclearDevChn(NamedChnType.Di, DevAN_DIPieceInEject);


            DeclearCfgParam(JFParamDescribe.Create(SCN_EjectDistance, typeof(double), JFValueLimit.MinLimit, new object[] { 0 }), "运行参数");
            DeclearCfgParam(JFParamDescribe.Create(SCN_PushLength, typeof(double), JFValueLimit.MinLimit, new object[] { 0 }), "运行参数");


            DeclearSPItemAlias(GPN_UnloadReady, typeof(bool), false);
            DeclearSPItemAlias(GPN_DetectDone, typeof(bool), false);
            DeclearSPItemAlias(GPN_AllowedLoad, typeof(bool), false);

        }


        static string DevAN_AxisEject = "出料轴"; //半自动上料时使用
        static string DevAN_DIEjectCldClose = "出料夹爪气缸闭合到位"; //无信号时表示夹紧
        static string DevAN_DOEjectCldCtrl = "出料夹爪气缸控制"; //False表示夹紧
        static string DevAN_DIPieceInEject = "出料口感应器";

        static string SCN_EjectDistance = "下料总行程"; //料片从检测位置移动到料仓的总长
        static string SCN_PushLength = "单次夹料最大行程"; //下料电机单次推料的最大长度

        //globle(system) data_pool variable 's Name
        static string GPN_UnloadReady = "下料仓准备收料";
        static string GPN_DetectDone = "视觉检测完成";
        static string GPN_AllowedLoad = "允许上料";








        /// <summary>
        /// 工站当前状态
        /// </summary>
        STStatus CurrCS
        {
            get { return (STStatus)CurrCustomStatus; }
        }

        void ChangeCS(STStatus cs)
        {
            if (CurrCustomStatus == (int)cs)
                return;
            ChangeCustomStatus((int)cs);
        }



        //执行结批动作
        protected override void ExecuteEndBatch()
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// 执行复位动作
        /// </summary>
        protected override void ExecuteReset()
        {
            throw new NotImplementedException();
        }

        protected override void OnPause()
        {
            throw new NotImplementedException();
        }

        protected override void OnResume()
        {
            throw new NotImplementedException();
        }

        protected override void OnStop()
        {
            
        }


        //动作流程开始前的准备
        protected override void PrepareWhenWorkStart()
        {
            
        }

        //主动做流程
        protected override void RunLoopInWork()
        {
            switch(CurrCS)
            {
                case STStatus.已停止:
                    break;
                case STStatus.等待检测Z轴避位: //归零时等待Z轴抬起后，再进行下一步动作
                    break;
                case STStatus.复位:
                    break;
                case STStatus.开始运行:
                    break;
                case STStatus.等待出料信号: //等待料仓向轨道送料完成信号
                    break;
                case STStatus.移动到待机位置:
                    break;
                case STStatus.出料: //轨道（自身）向检测位置送料
                    break;
                //case STStatus.等待检测完成:
                //    break;
                //case STStatus.等待出料信号://等待下料仓准备好
                //    break;
                //case STStatus.出料:
                //    break;
                default:
                    ExitWork(WorkExitCode.Exception, "工作流程中未命中的Custom-Status:" + CurrCS.ToString());
                    break;
            }
        }

        //动作流程推出前的清理
        protected override void CleanupWhenWorkExit()
        {
           
        }

    }
}
